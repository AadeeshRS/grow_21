"""Regression tests covering defects and invariants identified in the Phase 2 audit."""

import math
from pathlib import Path
import numpy as np
import pytest

from grow21_simulation_benchmark.closed_loop import (
    FixedDifficultyController,
    Grow21ModelBasedAdaptiveController,
    StreakAdaptiveController,
    run_closed_loop_comparison,
)
from grow21_simulation_benchmark.evaluate import compute_calibration_table
from grow21_simulation_benchmark.models import ReliabilityGatedDKT, VanillaDKT
from grow21_simulation_benchmark.tasks import TaskRegistry
import torch


@pytest.fixture
def registry():
    cfg_path = Path(__file__).parent.parent / "configs" / "default.yaml"
    return TaskRegistry.from_yaml(cfg_path)


def test_regression_oscillation_vs_variation():
    """Confirms direction reversals (oscillations) and total variation are computed correctly."""
    # Sequence with 4 monotonic steps up: 0.1, 0.2, 0.3, 0.4
    diffs_monotonic = [0.1, 0.2, 0.3, 0.4]
    reversals = 0
    for i in range(2, len(diffs_monotonic)):
        d_prev = diffs_monotonic[i - 1] - diffs_monotonic[i - 2]
        d_curr = diffs_monotonic[i] - diffs_monotonic[i - 1]
        if (d_prev * d_curr) < -1e-5:
            reversals += 1
    variation = sum(abs(diffs_monotonic[i] - diffs_monotonic[i - 1]) for i in range(1, len(diffs_monotonic)))

    assert reversals == 0, "Monotonic changes must have 0 direction reversals"
    assert pytest.approx(variation, abs=1e-5) == 0.3

    # Sequence with 2 reversals: 0.2 -> 0.4 -> 0.2 -> 0.4
    diffs_oscillating = [0.2, 0.4, 0.2, 0.4]
    reversals_osc = 0
    for i in range(2, len(diffs_oscillating)):
        d_prev = diffs_oscillating[i - 1] - diffs_oscillating[i - 2]
        d_curr = diffs_oscillating[i] - diffs_oscillating[i - 1]
        if (d_prev * d_curr) < -1e-5:
            reversals_osc += 1
    variation_osc = sum(abs(diffs_oscillating[i] - diffs_oscillating[i - 1]) for i in range(1, len(diffs_oscillating)))

    assert reversals_osc == 2, "Expected 2 direction reversals"
    assert pytest.approx(variation_osc, abs=1e-5) == 0.6


def test_regression_calibration_bin_sum_equals_total_events():
    """Confirms that calibration bin counts sum exactly to the number of test observations."""
    rng = np.random.RandomState(42)
    N = 1450
    y_true = rng.randint(0, 2, size=N)
    y_prob = rng.uniform(0.0, 1.0, size=N)

    bins, ece = compute_calibration_table(y_true, y_prob, num_bins=10)
    total_binned = sum(b["count"] for b in bins)
    assert total_binned == N, f"Bin count sum {total_binned} != total samples {N}"
    assert 0.0 <= ece <= 1.0


def test_regression_fairness_common_random_numbers(registry):
    """Verifies that all three controllers receive identical virtual learner profiles under paired seeds."""
    scenario_cfg = {
        "description": "audit_fairness_test",
        "initial_mastery_mean": 0.45,
        "initial_mastery_std": 0.15,
        "learning_rate_mean": 0.08,
        "learning_rate_std": 0.02,
        "forgetting_rate_mean": 0.02,
        "forgetting_rate_std": 0.01,
        "corruption_multiplier": 1.0,
    }

    results, _ = run_closed_loop_comparison(
        task_registry=registry,
        scenario_cfg=scenario_cfg,
        num_learners=5,
        trials_per_learner=20,
        seed=42,
    )

    fixed_inits = [r.initial_mastery_mean for r in results["fixed_difficulty"]]
    streak_inits = [r.initial_mastery_mean for r in results["streak_adaptive"]]
    target_inits = [r.initial_mastery_mean for r in results["target_adaptive"]]

    # Invariant: Every learner's initial mastery must match across all three policies
    assert fixed_inits == streak_inits == target_inits, (
        "Initial learner profiles must be strictly identical across controllers"
    )
