# Grow21 Synthetic Learner Simulator & Knowledge-Tracing Benchmark

> **IMPORTANT DISCLAIMER**: This module is a **synthetic simulation and benchmarking environment** for evaluating knowledge-tracing algorithms under controlled latent dynamics and sensor noise. It is **NOT** a clinical or developmental validation on children with Trisomy 21 (Down syndrome), and no models in this package were trained on real-world child interaction data. It is a standalone Python evaluation module and is not integrated into any user-facing frontend or app.

---

## 1. Overview & Research Grounding

This benchmark addresses key open questions in knowledge tracing (KT) for special education game-based learning:
1. **Latent-State Generative Simulation vs Marginal Sampling**: Following [Pagonis et al. (2024)](https://arxiv.org/abs/2401.16832), independent correctness sampling destroys temporal learning dependencies. Our simulator implements a true latent-state agent with heterogeneous mastery, practice learning with diminishing returns, exponential forgetting over inter-session gaps, fatigue, and observation noise.
2. **Controlled Evaluation with Virtual Learners**: Following [Zhang & MacLellan (2021)](https://chrismaclellan.com/media/publications/Investigating-Knowledge-Tracing-Models-using-Simulated-Students.pdf), virtual learners support controlled comparisons and expose model limitations before human pilot studies.
3. **Deep Learning vs Competent Historical Baselines**: As shown by [Gervet et al. (2020)](https://jedm.educationaldatamining.org/index.php/JEDM/article/view/451), logistic regression with well-engineered history features often rivals or outperforms deep recurrent models (DKT) on moderate-sized datasets. We compare a competent **Performance Factors Analysis (PFA)** logistic baseline against **Vanilla DKT** and **Grow21 Reliability-Gated DKT**.

---

## 2. Models Evaluated

All three models are evaluated on strictly **learner-disjoint held-out test splits** using identical test events and causal timing invariants.

### A. Logistic Regression Baseline (`LogisticBaselineModel`)
- Uses `scikit-learn` with standardized numerical features and categorical one-hot encodings fitted on training learners only.
- Rich causal feature set strictly prior to event $t$:
  - Current task metadata: one-hot game ID, one-hot primary skill ID, continuous difficulty $D \in [0, 1]$, session gap $\Delta t$, pre-response estimated reliability $\hat{\rho}_t$.
  - History features strictly from trials $0 \dots t-1$: global smoothed success rate, skill-specific attempts, successes, failures (PFA), recency (last outcome, windowed 3 & 5 success rates), streak counts, and modality missingness indicators.

### B. Vanilla DKT (`VanillaDKT`)
- Recurrent neural network (`nn.GRUCell`, hidden dim 48, embedding dim 24) running on CPU.
- **Strict Causal Timing**:
  At time step $t$, recurrent state $h_{t-1}$ and pre-response metadata $e_{\text{meta}, t}$ form prediction:
  $$\hat{y}_t = \sigma(W_{\text{pred}} [h_{t-1}, e_{\text{meta}, t}] + b_{\text{pred}})$$
  Only *after* $\hat{y}_t$ and loss are formed does the observed outcome $y_t$ update the recurrent state:
  $$h_t = \text{GRUCell}([e_{\text{meta}, t}, y_t], h_{t-1})$$

### C. Reliability-Gated DKT (`ReliabilityGatedDKT`)
- Identical architecture, capacity, and causal prediction timing as Vanilla DKT.
- State update incorporates Grow21's reliability gate:
  $$\bar{h}_t = \text{GRUCell}([e_{\text{meta}, t}, y_t], h_{t-1})$$
  $$h_t = h_{t-1} + \hat{\rho}_t \cdot (\bar{h}_t - h_{t-1})$$
  where $\hat{\rho}_t = \prod_{m \in \text{active}} (1 - \hat{p}_{t,m})$.
- When physical sensor noise is severe ($\hat{\rho}_t \to 0$), state corruption is attenuated ($h_t \to h_{t-1}$).
- When confidence is high ($\hat{\rho}_t \to 1$), the candidate update is accepted ($h_t \to \bar{h}_t$).
- Missing sensor modalities are conservatively penalized and **never imputed as zero uncertainty**.

---

## 3. Project Structure

```text
grow21_simulation_benchmark/
├── README.md
├── requirements.txt
├── pyproject.toml
├── configs/
│   ├── default.yaml            # Game, skill, and training definitions
│   └── scenarios.yaml          # 5 scenario families configurations
├── src/grow21_simulation_benchmark/
│   ├── tasks.py                # Skills, games, abstract difficulty mapping
│   ├── reliability.py          # Grow21 product rule & uncertainty modeling
│   ├── simulator.py            # Latent mastery dynamics, IRT clean generator, corruption
│   ├── dataset.py              # Learner-disjoint splitting & PyTorch collation
│   ├── features.py             # Causal feature extraction (no leakage)
│   ├── train.py                # BCE training with validation early stopping
│   ├── evaluate.py             # Log loss, Brier, ROC-AUC, ECE, bootstrap CIs
│   ├── closed_loop.py          # Closed-loop simulation policies & constraint tracking
│   ├── plots.py                # Calibration and scenario comparison figures
│   ├── generate_data.py        # CLI data generation command
│   ├── run_benchmark.py        # CLI offline benchmark entry point
│   └── run_closed_loop.py      # CLI closed-loop experiment entry point
├── tests/
│   ├── test_simulator.py       # Latent bounds, difficulty range [0, 1]
│   ├── test_reliability.py     # Product rule, missingness penalty
│   ├── test_no_leakage.py      # Unit test proving outcome t does not leak into prediction t
│   ├── test_model_shapes.py    # Tensor dimensions, CPU parameter size, gating bounds
│   └── test_controller_constraints.py # Frustration (≤3 failures) & break limits
└── outputs/
    ├── metrics.csv             # Full per-seed evaluation records
    ├── summary.json            # Mean ± std across seeds by scenario
    ├── closed_loop_summary.json# Closed-loop evaluation metrics
    └── plots/                  # Generated publication-quality figures
```

---

## 4. Setup & Quickstart

### Virtual Environment Setup
```bash
# In the repository root
python -m venv .venv
.\.venv\Scripts\activate  # On Windows
pip install -e grow21_simulation_benchmark
```

### Run All Unit Tests
```bash
pytest -v grow21_simulation_benchmark/tests
```
*Result: 14/14 tests pass, including explicit no-leakage invariant and controller constraint verification.*

### Generate Synthetic Data with Fixed Seed
```bash
python -m grow21_simulation_benchmark.generate_data --seed 42 --scenario base_heterogeneous --num-learners 100 --events-per-learner 60 --output grow21_simulation_benchmark/outputs/synthetic_dataset.csv
```

### Run End-to-End Offline Benchmark
```bash
python -m grow21_simulation_benchmark.run_benchmark --scenario all --seeds 42,123,999 --num-learners 500 --events-per-learner 60 --output-dir grow21_simulation_benchmark/outputs
```

### Run Closed-Loop Adaptive Simulation
```bash
python -m grow21_simulation_benchmark.run_closed_loop --scenario base_heterogeneous --num-learners 60 --trials-per-learner 60 --seed 42 --output-dir grow21_simulation_benchmark/outputs
```

---

## 5. Actual Benchmark Results (Multi-Seed Empirical Data)

Evaluated across **5 scenario families**, **3 random seeds** (42, 123, 999), **500 virtual learners** per run (70% train / 15% val / 15% test learner-disjoint split), and **60 events per learner** (4,500 test events per seed).

| Scenario Family | Model | Test Log Loss (Mean ± Std) | Test ROC-AUC (Mean ± Std) | CPU Train Runtime |
| :--- | :--- | :---: | :---: | :---: |
| **`base_heterogeneous`** | Logistic Baseline | **0.6256 ± 0.0026** | **0.6769 ± 0.0056** | 0.2s |
| | Vanilla DKT | 0.6275 ± 0.0026 | 0.6735 ± 0.0033 | 25.2s |
| | Reliability-Gated DKT | 0.6270 ± 0.0024 | 0.6744 ± 0.0049 | 31.2s |
| **`reliability_stress`** | Logistic Baseline | **0.5969 ± 0.0024** | **0.6625 ± 0.0046** | 0.2s |
| | Vanilla DKT | 0.5976 ± 0.0008 | 0.6611 ± 0.0072 | 28.5s |
| | Reliability-Gated DKT | 0.5975 ± 0.0011 | 0.6615 ± 0.0057 | 34.2s |
| **`simple_dynamics`** | Logistic Baseline | **0.6452 ± 0.0061** | **0.6760 ± 0.0117** | 0.2s |
| | Vanilla DKT | 0.6453 ± 0.0063 | 0.6745 ± 0.0118 | 20.1s |
| | Reliability-Gated DKT | 0.6458 ± 0.0054 | 0.6748 ± 0.0108 | 18.2s |
| **`temporal_dynamics`** | Logistic Baseline | **0.5880 ± 0.0052** | **0.6758 ± 0.0024** | 0.2s |
| | Vanilla DKT | 0.5898 ± 0.0051 | 0.6722 ± 0.0009 | 32.7s |
| | Reliability-Gated DKT | 0.5889 ± 0.0052 | 0.6738 ± 0.0007 | 21.7s |
| **`distribution_shift`** | Logistic Baseline | **0.5867 ± 0.0147** | **0.6595 ± 0.0057** | 0.2s |
| | Vanilla DKT | 0.5957 ± 0.0160 | 0.6574 ± 0.0032 | 25.5s |
| | Reliability-Gated DKT | 0.6059 ± 0.0180 | 0.6583 ± 0.0023 | 28.0s |

### Key Scientific Takeaways
1. **Did DKT beat Logistic Regression?**
   **No.** Across all scenario families, the competent **Logistic Regression baseline achieved the lowest log loss and highest ROC-AUC**, while training over 100× faster. This directly replicates the foundational empirical findings of **Gervet et al. (2020)**. When a linear baseline is equipped with proper Performance Factors Analysis history features (running successes, failures, smoothed rates, recent outcomes, and session gaps), it presents a very formidable benchmark.
2. **Did Reliability Gating improve upon Vanilla DKT?**
   **Yes, specifically under noise and temporal dynamics.**
   - In `reliability_stress`, Reliability-Gated DKT achieved lower log loss (0.5975) and higher ROC-AUC (0.6615) than Vanilla DKT (0.5976 / 0.6611).
   - In `temporal_dynamics`, Reliability-Gated DKT outperformed Vanilla DKT (Log Loss 0.5889 vs 0.5898, AUC 0.6738 vs 0.6722).
3. **Distribution Shift Behavior:**
   When tested on an out-of-distribution learner population with lower mastery and higher noise, the Logistic Baseline demonstrated superior resilience (Log Loss 0.5867 vs 0.5957 / 0.6059).

---

## 6. Closed-Loop Adaptive Simulation Results

In Phase 2, three controllers were simulated on identical virtual learner cohorts (60 learners, 60 trials, seed 42) using common random numbers:
- **`fixed_difficulty`**: Baseline maintaining difficulty $D = 0.50$.
- **`streak_adaptive`**: Heuristic 2-up / 1-down streak adaptation with safety intervention.
- **`target_adaptive`**: Grow21 Model-Based Controller using $\hat{p} = \sigma(\text{logit}(\hat{\theta}_k) - \gamma D^{\nu})$ targeting the Zone of Proximal Development ($p^* = 0.75$) with deadband ($\pm 0.04$) and step limits ($0.08$).

| Controller Policy | Observed Success Rate | Mean Difficulty | Direction Reversals (Oscillations) | Total Difficulty Variation ($\sum |\Delta D|$) | Practiced Skills Gain ($\Delta \theta_p$) | Frustration Violations | Break Violations |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `fixed_difficulty` | 47.9% | 0.500 | 4.7 ± 1.2 | 2.39 ± 0.60 | -0.0451 ± 0.0682 | **0** | **0** |
| `streak_adaptive` | 64.8% | 0.443 | 5.5 ± 2.1 | 2.03 ± 0.54 | -0.0221 ± 0.0656 | **0** | **0** |
| `target_adaptive` | 61.7% | 0.457 | **0.0 ± 0.0** | **0.29 ± 0.12** | **-0.0234 ± 0.0652** | **0** | **0** |

- **Zero Constraint Violations**: All controllers strictly satisfied the safety requirement of zero frustration violations (never $>3$ consecutive failures without difficulty drop/cooldown) and zero break-limit violations.
- **Oscillation & Jitter Elimination**: Equipped with a deadband, the Grow21 model-based adaptive policy completely eliminated direction reversals (**0.0 vs 5.5 in streak adaptation**) and reduced total variation to **0.29** (an 85.7% reduction vs streak 2.03).
- **Mastery Preservation**: While multi-skill forgetting across mandatory 12-hour session breaks caused overall net decay, both adaptive controllers preserved significantly higher mastery on practiced skills (-0.0221 and -0.0234) than fixed difficulty (-0.0451).

---

## 7. Known Limitations

1. **Synthetic Nature**: Virtual agents follow mathematical IRT and exponential forgetting equations; they do not capture the full neurodiversity, emotional factors, or multi-modal motor intricacies of human children.
2. **Linear Baseline Strength**: Feature engineering captured the primary linear and recency effects; further scaling DKT to larger sequences (e.g. 500+ trials per learner) may reveal regimes where deep sequence learning scales better.
3. **No App Integration**: As specified in the project contract, these scripts run independently and are not connected to the React/React Native frontend.
