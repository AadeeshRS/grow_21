"""CLI script for running the closed-loop adaptive simulation experiment."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import yaml

from .closed_loop import run_closed_loop_comparison
from .tasks import TaskRegistry


def main():
    parser = argparse.ArgumentParser(description="Run Grow21 Closed-Loop Simulation Experiment.")
    parser.add_argument(
        "--config",
        type=str,
        default="grow21_simulation_benchmark/configs/default.yaml",
        help="Default config YAML",
    )
    parser.add_argument(
        "--scenarios",
        type=str,
        default="grow21_simulation_benchmark/configs/scenarios.yaml",
        help="Scenarios YAML",
    )
    parser.add_argument(
        "--scenario",
        type=str,
        default="base_heterogeneous",
        help="Scenario for closed-loop evaluation",
    )
    parser.add_argument(
        "--num-learners",
        type=int,
        default=60,
        help="Number of virtual learners",
    )
    parser.add_argument(
        "--trials-per-learner",
        type=int,
        default=60,
        help="Trials per learner",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="grow21_simulation_benchmark/outputs",
        help="Output directory",
    )
    args = parser.parse_args()

    registry = TaskRegistry.from_yaml(args.config)
    with open(args.scenarios, "r", encoding="utf-8") as f:
        sc_cfg = yaml.safe_load(f)["scenarios"][args.scenario]

    print(f"Running Closed-Loop Experiment on scenario: {args.scenario} ({args.num_learners} learners, {args.trials_per_learner} trials, seed={args.seed})")
    results, events_df = run_closed_loop_comparison(
        task_registry=registry,
        scenario_cfg=sc_cfg,
        num_learners=args.num_learners,
        trials_per_learner=args.trials_per_learner,
        seed=args.seed,
    )

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    plots_dir = out_dir / "plots"
    plots_dir.mkdir(parents=True, exist_ok=True)

    # Save compact event-level CSV for full reproducibility and auditing
    events_csv_path = out_dir / "closed_loop_events.csv"
    events_df.to_csv(events_csv_path, index=False)
    print(f"Saved {len(events_df)} event-level closed-loop trials to {events_csv_path}")

    summary = {}
    for c_name, runs in results.items():
        gains_all = [r.mastery_gain_all_skills for r in runs]
        gains_practiced = [r.mastery_gain_practiced_skills for r in runs]
        obs_rates = [r.observed_success_rate for r in runs]
        clean_rates = [r.clean_success_rate for r in runs]
        reversals = [r.direction_reversals for r in runs]
        variations = [r.total_difficulty_variation for r in runs]
        mean_diffs = [r.mean_difficulty for r in runs]
        frust_viols = sum(r.frustration_violations for r in runs)
        break_viols = sum(r.break_limit_violations for r in runs)

        summary[c_name] = {
            "mastery_gain_all_skills_mean": round(float(np.mean(gains_all)), 4),
            "mastery_gain_all_skills_std": round(float(np.std(gains_all)), 4),
            "mastery_gain_practiced_skills_mean": round(float(np.mean(gains_practiced)), 4),
            "mastery_gain_practiced_skills_std": round(float(np.std(gains_practiced)), 4),
            "observed_success_rate_mean": round(float(np.mean(obs_rates)), 4),
            "clean_success_rate_mean": round(float(np.mean(clean_rates)), 4),
            "direction_reversals_mean": round(float(np.mean(reversals)), 3),
            "direction_reversals_std": round(float(np.std(reversals)), 3),
            "total_difficulty_variation_mean": round(float(np.mean(variations)), 3),
            "total_difficulty_variation_std": round(float(np.std(variations)), 3),
            "mean_difficulty": round(float(np.mean(mean_diffs)), 3),
            "total_frustration_violations": frust_viols,
            "total_break_limit_violations": break_viols,
        }

    summary_file = out_dir / "closed_loop_summary.json"
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"Closed loop summary saved to {summary_file}")

    # Plot closed-loop metrics comparison
    controllers = list(summary.keys())
    ctrl_labels = [c.replace("_", " ").title() for c in controllers]
    gains_p = [summary[c]["mastery_gain_practiced_skills_mean"] for c in controllers]
    gain_p_stds = [summary[c]["mastery_gain_practiced_skills_std"] for c in controllers]
    reversals = [summary[c]["direction_reversals_mean"] for c in controllers]
    variations = [summary[c]["total_difficulty_variation_mean"] for c in controllers]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.8))
    colors = ["#7f7f7f", "#ff7f0e", "#2ca02c"]

    # 1. Mastery gain on practiced skills
    ax1.bar(ctrl_labels, gains_p, yerr=gain_p_stds, capsize=4, color=colors, alpha=0.85)
    ax1.set_ylabel("Mastery Gain on Practiced Skills (Δθ)", fontsize=11)
    ax1.set_title("Targeted Skill Mastery Growth", fontsize=12, fontweight="bold")
    ax1.grid(True, axis="y", linestyle=":", alpha=0.6)

    # 2. Stability / Oscillations: Direction reversals vs Total Variation
    x = np.arange(len(controllers))
    w = 0.35
    ax2.bar(x - w/2, reversals, width=w, label="Direction Reversals (Oscillations)", color="#1f77b4", alpha=0.85)
    ax2.bar(x + w/2, variations, width=w, label="Total Difficulty Variation (Σ|ΔD|)", color="#d62728", alpha=0.85)
    ax2.set_xticks(x)
    ax2.set_xticklabels(ctrl_labels)
    ax2.set_ylabel("Count / Cumulative Variation", fontsize=11)
    ax2.set_title("Controller Difficulty Dynamics & Stability", fontsize=12, fontweight="bold")
    ax2.grid(True, axis="y", linestyle=":", alpha=0.6)
    ax2.legend()

    plt.tight_layout()
    plot_file = plots_dir / "closed_loop_comparison.png"
    plt.savefig(plot_file, dpi=200)
    plt.close()
    print(f"Closed-loop plot saved to {plot_file}")

    print("\n" + "=" * 95)
    print(f"{'Controller':<22} | {'Practiced Gain':<16} | {'All-Skills Gain':<16} | {'Reversals':<11} | {'Variation':<11} | {'Violations'}")
    print("-" * 95)
    for c, s in summary.items():
        gp_str = f"{s['mastery_gain_practiced_skills_mean']:.4f} ± {s['mastery_gain_practiced_skills_std']:.4f}"
        ga_str = f"{s['mastery_gain_all_skills_mean']:.4f} ± {s['mastery_gain_all_skills_std']:.4f}"
        rev_str = f"{s['direction_reversals_mean']:.1f}"
        var_str = f"{s['total_difficulty_variation_mean']:.2f}"
        viols = f"F={s['total_frustration_violations']}, B={s['total_break_limit_violations']}"
        print(f"{c:<22} | {gp_str:<16} | {ga_str:<16} | {rev_str:<11} | {var_str:<11} | {viols}")
    print("=" * 95)


if __name__ == "__main__":
    main()
