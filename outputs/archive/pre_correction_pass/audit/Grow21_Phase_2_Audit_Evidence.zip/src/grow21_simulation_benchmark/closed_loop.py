"""Closed-loop adaptive simulation experiment for Grow21.

Compares controller policies (Fixed, Streak Heuristic, and Grow21 Model-Based Adaptive)
acting on virtual learners, measuring latent mastery progression, difficulty oscillations,
and enforcing strict frustration and session break-limit constraints.
"""

from __future__ import annotations

import copy
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import pandas as pd

from .reliability import ReliabilityEngine
from .simulator import (
    SimulatorEvent,
    VirtualLearnerProfile,
    VirtualLearnerSimulator,
    generate_learner_profile,
)
from .tasks import TaskRegistry


@dataclass
class ClosedLoopRunResult:
    controller_name: str
    scenario_name: str
    learner_id: int
    initial_mastery_mean: float
    final_mastery_mean: float
    mastery_gain_all_skills: float
    mastery_gain_practiced_skills: float
    per_skill_gains: Dict[str, float]
    total_trials: int
    observed_success_rate: float
    clean_success_rate: float
    direction_reversals: int  # True oscillations: reversals in difficulty direction
    total_difficulty_variation: float  # Sum of |D_t - D_{t-1}|
    mean_difficulty: float
    frustration_violations: int  # Must be 0 (never >3 failures)
    break_limit_violations: int  # Must be 0 (never >15 trials without rest)


class ControllerPolicy:
    """Base interface for task and difficulty selection policies."""

    def __init__(
        self,
        task_registry: TaskRegistry,
        max_consecutive_failures: int = 3,
        max_session_trials: int = 15,
        cooldown_gap_hours: float = 2.0,
    ):
        self.registry = task_registry
        self.max_consecutive_failures = max_consecutive_failures
        self.max_session_trials = max_session_trials
        self.cooldown_gap_hours = cooldown_gap_hours
        self.consecutive_failures = 0
        self.session_trial_count = 0
        self.frustration_violations = 0
        self.break_limit_violations = 0

    def select_next_task(self, step_idx: int) -> Tuple[str, float, float]:
        """Returns (game_id, difficulty, time_gap_hours)."""
        raise NotImplementedError

    def observe_outcome(self, game_id: str, outcome: int, difficulty: float):
        """Updates controller state after trial response."""
        self.session_trial_count += 1
        if outcome == 0:
            self.consecutive_failures += 1
            if self.consecutive_failures > self.max_consecutive_failures:
                self.frustration_violations += 1
        else:
            self.consecutive_failures = 0


class FixedDifficultyController(ControllerPolicy):
    """Control condition: maintains constant difficulty (e.g. D=0.50) with cyclical game curriculum."""

    def __init__(
        self,
        task_registry: TaskRegistry,
        fixed_difficulty: float = 0.50,
        max_consecutive_failures: int = 3,
        max_session_trials: int = 15,
        cooldown_gap_hours: float = 2.0,
    ):
        super().__init__(
            task_registry,
            max_consecutive_failures=max_consecutive_failures,
            max_session_trials=max_session_trials,
            cooldown_gap_hours=cooldown_gap_hours,
        )
        self.fixed_difficulty = fixed_difficulty
        self.games = task_registry.game_ids

    def select_next_task(self, step_idx: int) -> Tuple[str, float, float]:
        game_id = self.games[step_idx % len(self.games)]

        # Check session break constraint
        if self.session_trial_count >= self.max_session_trials:
            time_gap = 12.0  # Mandatory inter-session rest
            self.session_trial_count = 0
        else:
            time_gap = 0.02

        # Check frustration safety rule
        if self.consecutive_failures >= self.max_consecutive_failures:
            # Temporary safety drop in difficulty
            diff = max(0.10, self.fixed_difficulty - 0.25)
            self.consecutive_failures = 0
            time_gap = max(time_gap, self.cooldown_gap_hours)
        else:
            diff = self.fixed_difficulty

        return game_id, round(diff, 3), time_gap


class StreakAdaptiveController(ControllerPolicy):
    """Heuristic adaptive controller adjusting difficulty based on success/failure streaks."""

    def __init__(
        self,
        task_registry: TaskRegistry,
        initial_difficulty: float = 0.40,
        up_step: float = 0.06,
        down_step: float = 0.08,
        max_consecutive_failures: int = 3,
        max_session_trials: int = 15,
        cooldown_gap_hours: float = 2.0,
    ):
        super().__init__(
            task_registry,
            max_consecutive_failures=max_consecutive_failures,
            max_session_trials=max_session_trials,
            cooldown_gap_hours=cooldown_gap_hours,
        )
        self.current_difficulty = initial_difficulty
        self.up_step = up_step
        self.down_step = down_step
        self.consecutive_successes = 0
        self.games = task_registry.game_ids

    def select_next_task(self, step_idx: int) -> Tuple[str, float, float]:
        game_id = self.games[step_idx % len(self.games)]

        if self.session_trial_count >= self.max_session_trials:
            time_gap = 12.0
            self.session_trial_count = 0
        else:
            time_gap = 0.02

        # Frustration safety intervention
        if self.consecutive_failures >= self.max_consecutive_failures:
            self.current_difficulty = max(0.08, self.current_difficulty - 0.25)
            self.consecutive_failures = 0
            time_gap = max(time_gap, self.cooldown_gap_hours)

        return game_id, round(self.current_difficulty, 3), time_gap

    def observe_outcome(self, game_id: str, outcome: int, difficulty: float):
        super().observe_outcome(game_id, outcome, difficulty)
        if outcome == 1:
            self.consecutive_successes += 1
            if self.consecutive_successes >= 2:
                self.current_difficulty = min(0.95, self.current_difficulty + self.up_step)
                self.consecutive_successes = 0
        else:
            self.consecutive_successes = 0
            self.current_difficulty = max(0.08, self.current_difficulty - self.down_step)


class Grow21ModelBasedAdaptiveController(ControllerPolicy):
    """Grow21 Model-Based Adaptive Controller.

    Uses Grow21's predicted-success equation:
      p_hat = sigmoid(logit(theta_k) - gamma[g, k] * D**nu_D)
    to choose difficulty D targeting the Zone of Proximal Development (ZPD target ~0.75),
    with deadband, step-size limits, and frustration/break constraints.
    """

    def __init__(
        self,
        task_registry: TaskRegistry,
        target_success_prob: float = 0.75,
        initial_difficulty: float = 0.45,
        gamma: float = 2.4,
        nu_D: float = 1.0,
        deadband: float = 0.04,
        max_step_change: float = 0.08,
        min_difficulty: float = 0.08,
        max_difficulty: float = 0.95,
        max_consecutive_failures: int = 3,
        max_session_trials: int = 15,
        cooldown_gap_hours: float = 2.0,
    ):
        super().__init__(
            task_registry,
            max_consecutive_failures=max_consecutive_failures,
            max_session_trials=max_session_trials,
            cooldown_gap_hours=cooldown_gap_hours,
        )
        self.target_prob = target_success_prob
        self.current_difficulty = initial_difficulty
        self.gamma = gamma
        self.nu_D = nu_D
        self.deadband = deadband
        self.max_step_change = max_step_change
        self.min_difficulty = min_difficulty
        self.max_difficulty = max_difficulty
        self.games = task_registry.game_ids

        # Estimated belief mastery theta_hat per skill
        self.estimated_mastery: Dict[str, float] = {
            s: 0.45 for s in task_registry.skill_ids
        }

    def predict_success_prob(self, skill_id: str, difficulty: float) -> float:
        """Computes p_hat = sigmoid(logit(theta_k) - gamma * D**nu_D)."""
        theta = float(np.clip(self.estimated_mastery.get(skill_id, 0.45), 0.05, 0.95))
        logit_theta = math.log(theta / (1.0 - theta))
        d_val = float(np.clip(difficulty, 0.0, 1.0))
        power_term = self.gamma * (d_val ** self.nu_D)
        logit_diff = logit_theta - power_term
        # Stable sigmoid
        return 1.0 / (1.0 + math.exp(-max(-20.0, min(20.0, logit_diff))))

    def select_next_task(self, step_idx: int) -> Tuple[str, float, float]:
        game_id = self.games[step_idx % len(self.games)]
        prim_skill = self.registry.games[game_id].primary_skill

        # Check session break constraint
        if self.session_trial_count >= self.max_session_trials:
            time_gap = 12.0
            self.session_trial_count = 0
        else:
            time_gap = 0.02

        # Frustration safety intervention
        if self.consecutive_failures >= self.max_consecutive_failures:
            self.current_difficulty = max(self.min_difficulty, self.current_difficulty - 0.25)
            self.consecutive_failures = 0
            time_gap = max(time_gap, self.cooldown_gap_hours)
            return game_id, round(self.current_difficulty, 3), time_gap

        # Grow21 Model-Based Controller Difficulty Optimization
        # Solve for D* such that p_hat(D*) == target_prob
        theta = float(np.clip(self.estimated_mastery.get(prim_skill, 0.45), 0.05, 0.95))
        logit_theta = math.log(theta / (1.0 - theta))
        logit_target = math.log(self.target_prob / (1.0 - self.target_prob))

        # logit_theta - gamma * (D*)**nu_D = logit_target
        # gamma * (D*)**nu_D = logit_theta - logit_target
        req_power = (logit_theta - logit_target) / self.gamma

        if req_power <= 0.0:
            target_D = self.min_difficulty
        else:
            target_D = float(np.clip(req_power ** (1.0 / self.nu_D), self.min_difficulty, self.max_difficulty))

        # Check deadband: if current difficulty already yields probability within deadband of target, hold steady
        current_pred_p = self.predict_success_prob(prim_skill, self.current_difficulty)
        if abs(current_pred_p - self.target_prob) <= self.deadband:
            target_D = self.current_difficulty

        # Apply maximum step change limit (smooth control)
        step_delta = float(np.clip(target_D - self.current_difficulty, -self.max_step_change, self.max_step_change))
        self.current_difficulty = float(np.clip(
            self.current_difficulty + step_delta, self.min_difficulty, self.max_difficulty
        ))

        return game_id, round(self.current_difficulty, 3), time_gap

    def observe_outcome(self, game_id: str, outcome: int, difficulty: float):
        super().observe_outcome(game_id, outcome, difficulty)
        prim_skill = self.registry.games[game_id].primary_skill

        # Online belief update on skill mastery (Bayesian smoothed knowledge update)
        curr_m = self.estimated_mastery.get(prim_skill, 0.45)
        if outcome == 1:
            # Positive observation reinforces mastery belief
            new_m = curr_m + 0.08 * (0.95 - curr_m)
        else:
            # Negative observation reduces mastery belief
            new_m = curr_m - 0.08 * (curr_m - 0.05)
        self.estimated_mastery[prim_skill] = float(np.clip(new_m, 0.05, 0.95))


def run_closed_loop_comparison(
    task_registry: TaskRegistry,
    scenario_cfg: Dict[str, Any],
    num_learners: int = 60,
    trials_per_learner: int = 60,
    seed: int = 42,
    cooldown_gap_hours: float = 2.0,
) -> Tuple[Dict[str, List[ClosedLoopRunResult]], pd.DataFrame]:
    """Runs paired closed-loop simulation across controller strategies using identical initial learner profiles.

    Returns:
        (results_dict, event_level_df)
    """
    rng = np.random.RandomState(seed)
    rel_engine = ReliabilityEngine(task_registry)

    controllers_factories = {
        "fixed_difficulty": lambda: FixedDifficultyController(
            task_registry, fixed_difficulty=0.50, cooldown_gap_hours=cooldown_gap_hours
        ),
        "streak_adaptive": lambda: StreakAdaptiveController(
            task_registry, initial_difficulty=0.45, cooldown_gap_hours=cooldown_gap_hours
        ),
        "target_adaptive": lambda: Grow21ModelBasedAdaptiveController(
            task_registry, target_success_prob=0.75, initial_difficulty=0.45, cooldown_gap_hours=cooldown_gap_hours
        ),
    }

    results: Dict[str, List[ClosedLoopRunResult]] = {c: [] for c in controllers_factories}
    all_events: List[Dict[str, Any]] = []

    for l_id in range(num_learners):
        base_profile = generate_learner_profile(
            learner_id=l_id,
            skill_ids=task_registry.skill_ids,
            rng=rng,
            scenario_params=scenario_cfg,
        )

        for c_name, c_factory in controllers_factories.items():
            learner_prof = copy.deepcopy(base_profile)
            sim = VirtualLearnerSimulator(
                profile=learner_prof,
                task_registry=task_registry,
                reliability_engine=rel_engine,
            )
            controller = c_factory()

            init_mastery_dict = dict(sim.current_mastery)
            init_m_mean = float(np.mean(list(init_mastery_dict.values())))

            obs_outcomes = []
            clean_outcomes = []
            diffs = []
            practiced_skills = set()

            # Seeded per-learner stream to ensure fair common random numbers
            sim_rng = np.random.RandomState(seed * 1000 + l_id)

            for step in range(trials_per_learner):
                gid, diff, gap = controller.select_next_task(step)
                ev = sim.step(
                    game_id=gid,
                    difficulty=diff,
                    time_gap_hours=gap,
                    rng=sim_rng,
                    scenario_params=scenario_cfg,
                )
                controller.observe_outcome(gid, ev.observed_outcome, diff)

                obs_outcomes.append(ev.observed_outcome)
                clean_outcomes.append(ev.clean_outcome)
                diffs.append(diff)
                practiced_skills.add(ev.primary_skill)

                all_events.append({
                    "controller": c_name,
                    "learner_id": l_id,
                    "step_idx": step,
                    "game_id": gid,
                    "primary_skill": ev.primary_skill,
                    "difficulty": diff,
                    "time_gap_hours": gap,
                    "observed_outcome": ev.observed_outcome,
                    "clean_outcome": ev.clean_outcome,
                    "estimated_reliability": ev.estimated_reliability,
                })

            final_mastery_dict = dict(sim.current_mastery)
            final_m_mean = float(np.mean(list(final_mastery_dict.values())))

            # Calculate direction reversals (true oscillations)
            reversals = 0
            for i in range(2, len(diffs)):
                d_prev = diffs[i - 1] - diffs[i - 2]
                d_curr = diffs[i] - diffs[i - 1]
                if (d_prev * d_curr) < -1e-5:
                    reversals += 1

            total_variation = sum(abs(diffs[i] - diffs[i - 1]) for i in range(1, len(diffs)))

            # Per skill gains
            per_skill = {s: round(final_mastery_dict[s] - init_mastery_dict[s], 4) for s in task_registry.skill_ids}
            practiced_gains = [per_skill[s] for s in practiced_skills]
            practiced_m_gain = float(np.mean(practiced_gains)) if practiced_gains else 0.0

            res = ClosedLoopRunResult(
                controller_name=c_name,
                scenario_name=scenario_cfg.get("description", "custom"),
                learner_id=l_id,
                initial_mastery_mean=round(init_m_mean, 4),
                final_mastery_mean=round(final_m_mean, 4),
                mastery_gain_all_skills=round(final_m_mean - init_m_mean, 4),
                mastery_gain_practiced_skills=round(practiced_m_gain, 4),
                per_skill_gains=per_skill,
                total_trials=trials_per_learner,
                observed_success_rate=round(float(np.mean(obs_outcomes)), 4),
                clean_success_rate=round(float(np.mean(clean_outcomes)), 4),
                direction_reversals=reversals,
                total_difficulty_variation=round(float(total_variation), 3),
                mean_difficulty=round(float(np.mean(diffs)), 3),
                frustration_violations=controller.frustration_violations,
                break_limit_violations=controller.break_limit_violations,
            )
            results[c_name].append(res)

    events_df = pd.DataFrame(all_events)
    return results, events_df
